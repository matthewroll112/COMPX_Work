﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Matthew Rolleston ID:1569761
namespace Ex2
{
    public partial class Form1 : Form
    {
        //Constants
        const int COL_ROW = 10;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDraw_Click(object sender, EventArgs e)
        {
            //Graphics & Pen & Brush
            Graphics board = pictureBox1.CreateGraphics();
            Pen p = new Pen(Color.Black,2);
            Brush fl = new SolidBrush(Color.LightPink);
            Brush mid = new SolidBrush(Color.LightBlue);
            Brush all = new SolidBrush(Color.LightGreen);


            try
            {
                //Vars
                int rows = int.Parse(textBoxRows.Text);
                int width = pictureBox1.Width / COL_ROW;
                int height = pictureBox1.Height / rows;
                int x = 0;
                int y = 0;

                //Checking if num rows is between required amount
                if(rows <= 10 && rows >= 5)
                {
                    //Loop for rows
                    for (int i = 0; i < rows; i++)
                    {
                        x = 0;
                        //Loop for cols
                        for (int a = 0; a < COL_ROW; a++)
                        {
                            //Filling rectangles with color based on column number
                            if (a == 0 || a == 9)
                            {
                                board.DrawRectangle(p, x, y, width, height);
                                board.FillRectangle(fl, x + 1, y + 1, width - 2, height - 2); //+1 and -2 to show outline around rectangles
                                
                            }
                            else if (a == 4 || a == 5)
                            {
                                board.DrawRectangle(p, x, y, width, height);
                                board.FillRectangle(mid, x + 1, y + 1, width - 2, height - 2);
                            }
                            else
                            {
                                board.DrawRectangle(p, x, y, width, height);
                                board.FillRectangle(all, x + 1, y + 1, width - 2, height - 2);
                            }
                            x += width;
                        }
                        y += height;
                    }
                }
                else
                {
                    //Msgbox
                    MessageBox.Show("Number of rows is invalid. Please enter a number from 5 to 10", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //Clearing and focusing
                    textBoxRows.Clear();
                    textBoxRows.Focus();
                }
                
                
            }
            catch
            {
                //Msgbox
                MessageBox.Show("Error, try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Clearing and focusing
                pictureBox1.Refresh();
                textBoxRows.Clear();
                textBoxRows.Focus();
            }
            
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            //Clears picture box and text box
            pictureBox1.Refresh();
            textBoxRows.Clear();
            textBoxRows.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

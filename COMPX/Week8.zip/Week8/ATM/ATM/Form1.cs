﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Matthew Rolleston ID:1569761
namespace ATM
{
    public partial class Form1 : Form
    {
        int balance = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //CheckDeposit
        private bool checkDeposit(int num)
        {
            //If num less than 20 or num is greater than 200; return false, show error message
            if (num < 20 || num > 200)
            {
                MessageBox.Show("Number must be between 20 - 200", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else
            {
                return true;
            }
        }
        //Deposit
        private void deposit()
        {
            int deposit = int.Parse(textBox1.Text);

            if (checkDeposit(deposit) == true)
            {
                balance += deposit;
            }
            labelBalance.Text = "$" + balance.ToString();
            textBox1.Clear();
            textBox1.Focus();
        }

        private void buttonDepo_Click(object sender, EventArgs e)
        {
            //Calling deposit method
            deposit();
        }
        //CheckWithdrawl
        private bool checkWithdrawl(int num)
        {
            //If num less than 20 or num is greater than balance; return false, show error message
            if(num < 20 || num > balance)
            {
                MessageBox.Show("Number must be between 20 and Current Balance", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else
            {
                return true;
            }
        }

        private void buttonWith_Click(object sender, EventArgs e)
        {
            //Getting withdraw amount from textbox
            int withdraw = int.Parse(textBox1.Text);
            bool x = checkWithdrawl(withdraw);
            
            //If true is returned withdraw specified amount
            if (x == true)
            {
                balance -= withdraw;
            }

            labelBalance.Text = "$" + balance.ToString();
        }
    }
}

﻿namespace ATM
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.buttonDepo = new System.Windows.Forms.Button();
            this.buttonWith = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.labelBalance = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(255, 272);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Current Balance: ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(343, 335);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            // 
            // buttonDepo
            // 
            this.buttonDepo.Location = new System.Drawing.Point(267, 387);
            this.buttonDepo.Name = "buttonDepo";
            this.buttonDepo.Size = new System.Drawing.Size(112, 36);
            this.buttonDepo.TabIndex = 2;
            this.buttonDepo.Text = "Deposit";
            this.buttonDepo.UseVisualStyleBackColor = true;
            this.buttonDepo.Click += new System.EventHandler(this.buttonDepo_Click);
            // 
            // buttonWith
            // 
            this.buttonWith.Location = new System.Drawing.Point(412, 387);
            this.buttonWith.Name = "buttonWith";
            this.buttonWith.Size = new System.Drawing.Size(112, 36);
            this.buttonWith.TabIndex = 3;
            this.buttonWith.Text = "Withdraw";
            this.buttonWith.UseVisualStyleBackColor = true;
            this.buttonWith.Click += new System.EventHandler(this.buttonWith_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.Red;
            this.buttonExit.ForeColor = System.Drawing.Color.White;
            this.buttonExit.Location = new System.Drawing.Point(713, 12);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 4;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // labelBalance
            // 
            this.labelBalance.AutoSize = true;
            this.labelBalance.Location = new System.Drawing.Point(343, 272);
            this.labelBalance.Name = "labelBalance";
            this.labelBalance.Size = new System.Drawing.Size(0, 13);
            this.labelBalance.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelBalance);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonWith);
            this.Controls.Add(this.buttonDepo);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button buttonDepo;
        private System.Windows.Forms.Button buttonWith;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label labelBalance;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Matthew Rolleston ID:1569761
namespace Practical
{
    public partial class Form1 : Form
    {
        //The minimum number of hours to display
        const int MIN_HOURS = 1;
        //The maximum number of hours to display
        const int MAX_HOURS = 24;
        //The number of days to display
        const int NUM_DAYS = 7;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //Clear click event
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Clears textbox and picturebox, focuses on textbox
            pictureBoxDisplay.Refresh();
            textBox1.Clear();
            textBox1.Focus();
        }
        //Draw Planner click event
        private void drawPlannerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                //Get Set number of hours
                int hours = int.Parse(textBox1.Text);

                if(hours > MIN_HOURS && hours < MAX_HOURS)
                {
                    //Variables
                    int y = 0;

                    //Creating graohics object linked to picturebox
                    Graphics planner = pictureBoxDisplay.CreateGraphics();
                    for (int i = 0; i < hours; i++)
                    {
                        DrawRow(planner, y, pictureBoxDisplay.Width / NUM_DAYS, pictureBoxDisplay.Height / hours);
                        y += pictureBoxDisplay.Height / hours;
                    }
                }
                else
                {
                    MessageBox.Show("Number of hours is not in parameters (1-24)", "Error", MessageBoxButtons.OK);
                    textBox1.Clear();
                    textBox1.Focus();
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                textBox1.Clear();
                textBox1.Focus();
            }
            
        }
        //DrawSquare method
        //private void DrawSqaure(Graphics paper, int y, int width, int height, Color color)
        //{
        //    int x = 0;
        //    Pen pen = new Pen(Color.Black, 2);

        //    paper.DrawRectangle(pen, x, y, width, height);
        //}
        private void DrawRow(Graphics paper, int y, int width, int height)
        {
            int x = 0;

            Pen pen = new Pen(Color.Black, 2);
            Brush end = new SolidBrush(Color.LightBlue); //Weekend color
            Brush day = new SolidBrush(Color.White); //Weekday color

            for (int i = 0; i < NUM_DAYS; i++)
            {
                if(i < 5)
                {
                    paper.DrawRectangle(pen, x, y, width, height);
                    paper.FillRectangle(day, x+1, y+1, width-1, height-1);
                }
                else
                {
                    paper.DrawRectangle(pen, x, y, width, height);
                    paper.FillRectangle(end, x + 1, y + 1, width - 1, height - 1);
                }
                x += width;
            }
        }
    }
}

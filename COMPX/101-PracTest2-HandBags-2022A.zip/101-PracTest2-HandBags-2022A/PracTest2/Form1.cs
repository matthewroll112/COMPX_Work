﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracTest2
{
    public partial class Form1 : Form
    {
        //Name: Matthew Rolleston
        //ID: 1569761

        //Width of a hand bag
        const int BAG_WIDTH = 50;
        //Height of a hand bag
        const int BAG_HEIGHT = 50;
        //The number of columns of hand bags to draw
        const int NUM_COLUMNS = 10;
        //The gap between rows and columns
        const int GAP = 10;
        //Max rows
        const int MAX_ROWS = 10;
        //Min rows
        const int MIN_ROWS = 2;    
        
        

        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Exit button, exits application
        /// </summary>
        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// Clear button, clears textbox and picturebox display, sets focus to textbox
        /// </summary>
        private void buttonClear_Click(object sender, EventArgs e)
        {
            //Clearing picture box
            pictureBoxDisplay.Refresh();
            //Clearing textbox and focusing
            textBoxRows.Clear();
            textBoxRows.Focus();
        }
        /// <summary>
        /// Draw hand bags button, using loops and vars to draw boxes, uses try and catch
        /// </summary>
        private void buttonDraw_Click(object sender, EventArgs e)
        {
            try
            {
                //Get set rows from textbox
                int rows = int.Parse(textBoxRows.Text);
                if(rows <= MAX_ROWS && rows >= MIN_ROWS)
                {
                    //Vars
                    int y = 0;
                    int x = 0;

                    //Graphics vars
                    Graphics box = pictureBoxDisplay.CreateGraphics();
                    Pen pen = new Pen(Color.Black, 3);
                    Brush all = new SolidBrush(Color.Red);
                    Brush others = new SolidBrush(Color.Purple);

                    //Loops for constructing rows in picturebox
                    for(int i = 0; i < rows; i++)
                    {

                        for(int a = 0; a < NUM_COLUMNS; a++)
                        {
                            //changing color of every 3rd col
                            if((a + 1) % 3 == 0)
                            {
                                if(a == 0)
                                {
                                    box.DrawRectangle(pen, x, y, BAG_WIDTH, BAG_HEIGHT);
                                    box.FillRectangle(all, x, y, BAG_WIDTH, BAG_HEIGHT);
                                }
                                else
                                {
                                    box.DrawRectangle(pen, x, y, BAG_WIDTH, BAG_HEIGHT);
                                    box.FillRectangle(others, x, y, BAG_WIDTH, BAG_HEIGHT);
                                } 
                            }
                            //Drawing every other bag
                            else
                            {
                                box.DrawRectangle(pen, x, y, BAG_WIDTH, BAG_HEIGHT);
                                box.FillRectangle(all, x, y, BAG_WIDTH, BAG_HEIGHT);
                            }
                            //Changing x for next bag
                            x += (BAG_WIDTH + GAP);
                        }
                        //Changing y var and x var for next row
                        y += (BAG_HEIGHT + GAP);
                        x = 0;
                    }
                }
                else
                {
                    //Error message
                    MessageBox.Show("Number of rows is not in parameters(2 - 10)", "Error", MessageBoxButtons.OK);
                    //Textbox clear and focus
                    ClearTextBox();
                    //Picture box clear
                    pictureBoxDisplay.Refresh();
                }
            }
            catch (Exception ex)
            {
                //Error message
                MessageBox.Show(ex.Message);
                //Textbox clear and focus
                ClearTextBox();
                //Picture box clear
                pictureBoxDisplay.Refresh();
            }
        }
        /// <summary>
        /// Cleartextbox method, clears and sets focus to textBoxRows
        /// </summary>
        private void ClearTextBox()
        {
            //Clearing
            textBoxRows.Clear();
            //Focusing
            textBoxRows.Focus();
        }
        
    }
}

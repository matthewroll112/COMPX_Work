﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PracticalTest3
{
    public partial class Form1 : Form
    {
        //Name: Matthew Rolleston
        //Id: 1569761

        //The number of columns in the grid
        const int NUM_COLUMNS = 26;
        //The number of rows in the grid
        const int NUM_ROWS = 26;
        //The size of each quadrant in the grid
        const int QUADRANT_SIZE = 20;
        //Colors for the various terrain tiles
        Color QUADRANT_COLOR = Color.Black;
        Color SPIRAL_GALAXY_COLOR = Color.Purple;
        Color ELLIPTICAL_GALAXY_COLOR = Color.Orange;
        Color IRREGULAR_GALAXY_COLOR = Color.Yellow;
        //Class scope lists for info on galaxies
        List<string> types = new List<string>();
        List<int> blackHoleNums = new List<int>();
        List<int> solarNums = new List<int>();
        List<int> cols = new List<int>();
        List<string> rowLetts = new List<string>();
        //Types of galaxies
        string[] typesGalaxies = { "Elliptical", "Spiral", "Irregular" };
        public Form1()
        {
            InitializeComponent();
            //Adding items to combo box
            comboBox1.Items.AddRange(typesGalaxies);
        }

        /// <summary>
        /// Converts the letter that represents a row into
        /// a y position in the grid.
        /// </summary>
        /// <param name="row">Letter of the row</param>
        /// <returns>The y position of the row in the grid</returns>
        private int CalcYPos(string row)
        {
            int y = (row[0] - 'A') * QUADRANT_SIZE;

            return y;
        }
        /// <summary>
        /// Passed column value and returns x position for galaxy in grid
        /// </summary>
        /// <param name="col"></param>
        /// <returns></returns>
        private int CalcXPos(int col)
        {
            int x = (col - 1) * QUADRANT_SIZE;
            return x;
        }
        /// <summary>
        /// Display a qudrant in the grid at the given x and y position in
        /// the given colour.
        /// </summary>
        /// <param name="paper">Where to draw the tile</param>
        /// <param name="x">The x position of the tile</param>
        /// <param name="y">The y position of the tile</param>
        /// <param name="quadrantColor">The colour of the quadrant</param>
        private void DisplayQuadrant(Graphics paper, int x, int y, Color quadrantColor)
        {
            SolidBrush br = new SolidBrush(quadrantColor);
            Pen pen1 = new Pen(Color.White, 1);
            paper.FillRectangle(br, x, y, QUADRANT_SIZE, QUADRANT_SIZE);
            paper.DrawRectangle(pen1, x, y, QUADRANT_SIZE, QUADRANT_SIZE);
        }

        /// <summary>
        /// Display the galaxy at the given x and y value in the given colour.
        /// </summary>
        /// <param name="paper">Where to draw the weapon</param>
        /// <param name="x">The x position of the weapon</param>
        /// <param name="y">The y position of the weapon</param>
        /// <param name="galaxyColor">The colour of the galaxy</param>
        private void DisplayGalaxy(Graphics paper, int x, int y, Color galaxyColor)
        {
            SolidBrush br = new SolidBrush(galaxyColor);

            //Draw the quadrant
            DisplayQuadrant(paper, x, y, QUADRANT_COLOR);
            
            //Draw the galaxy inside the quadrant
            paper.FillEllipse(br, x, y, QUADRANT_SIZE, QUADRANT_SIZE);
        }

        /// <summary>
        /// Display the grid of quadrants.
        /// </summary>
        /// <param name="paper">Where to draw the grid</param>
        private void DisplayGrid(Graphics paper)
        {
            //x and y position of the current quadrant
            int x = 0;
            int y = 0;
            //For each row of quadrants to draw
            for (int row = 1; row <= NUM_ROWS; row++)
            {
                //For each quadrant to draw in the current row
                for (int col = 1; col <= NUM_COLUMNS; col++)
                {
                    //Draw the quadrant at the current x and y position
                    DisplayQuadrant(paper, x, y, QUADRANT_COLOR);
                    //Shift x to the right by width of quadrant
                    x += QUADRANT_SIZE;
                }
                //Shift y down by height of quadrant
                y += QUADRANT_SIZE;
                //Shift x back to start of row
                x = 0;
            }
        }
        /// <summary>
        /// Exits app
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// Opens file and read lines into var then displays in listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Graphics
            Graphics paper = pictureBoxMap.CreateGraphics();
            //Declaring variables
            int galaxiesCount = 0;
            StreamReader reader;
            string line;
            //Setting filter for dialog control
            openFileDialog1.Filter = "CSV Files|*.csv|All Files|*.*";
            //Checking if user has selected file to open
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    //Displayiong grid of empty tiles
                    DisplayGrid(paper);
                    //Opening file
                    reader = File.OpenText(openFileDialog1.FileName);
                    //Loop until end of file
                    while (!reader.EndOfStream)
                    {
                        //Reading a line from file
                        line = reader.ReadLine();
                        //Split at comma and add to array
                        string[] values = line.Split(',');
                        if (values.Length == 5)
                        {
                            //Places elements from array into seperate vars
                            string type = values[0];
                            int blackHoleNum = int.Parse(values[1]);
                            int solarNum = int.Parse(values[2]);
                            int col = int.Parse(values[3]);
                            string rowLetter = values[4];
                            //Adding data to lists
                            types.Add(type);
                            blackHoleNums.Add(blackHoleNum);
                            solarNums.Add(solarNum);
                            cols.Add(col);
                            rowLetts.Add(rowLetter);

                            //Displaying each var using padding into listbox
                            listBoxData.Items.Add(string.Format("{0}{1}{2}{3}{4}", type, blackHoleNum.ToString().PadLeft(25 - type.Length), solarNum.ToString().PadLeft(10), col.ToString().PadLeft(10), rowLetter.PadLeft(10))); //NOTE: Padding suits my pc, might be to high for others
                            
                            //Calculating x and y pos
                            int x = CalcXPos(col);
                            int y = CalcYPos(rowLetter);
                            //IF structure to see what type galaxy is
                            if(type.ToLower() == "elliptical")
                            {
                                //Displaying galaxy using method with correct color to type
                                DisplayGalaxy(paper, x, y, ELLIPTICAL_GALAXY_COLOR);
                            }
                            else if(type.ToLower() == "spiral")
                            {
                                DisplayGalaxy(paper, x, y, SPIRAL_GALAXY_COLOR);
                            }
                            else
                            {
                                DisplayGalaxy(paper, x, y, IRREGULAR_GALAXY_COLOR);
                            }

                            //Adding 1 to galaxy count
                            galaxiesCount++;
                        }
                        else
                        {
                            Console.WriteLine("Galaxy Number " + galaxiesCount + " does not contain enough information");
                        }
                    }
                    reader.Close();
                    MessageBox.Show("Number of galaxies read: " + galaxiesCount, "Galaxy Count", MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                //Displays error to 
                MessageBox.Show(ex.Message);
            }
        }
        /// <summary>
        /// Displays number of galaxies that match type entered into combo box
        /// Count displayed in msgbox window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void countGalaxiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Count var
            int count = 0;
            //Getting combo box selected item
            int selected = comboBox1.SelectedIndex;
            //Checking to see what is selected in combo box
            //Counting what strings in types list match selected index
            foreach(string s in types)
            {
                if (s.ToLower() == typesGalaxies[selected].ToLower()) count++;
            }
            //Displaying count
            MessageBox.Show("Number of " + typesGalaxies[selected] + " galaxies: " + count, "Count of Galaxies", MessageBoxButtons.OK);
        }
        /// <summary>
        /// Changing color of selected galaxy in listbox to red
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listBoxData_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Creating graphics
            Graphics paper = pictureBoxMap.CreateGraphics();
            //Getting index
            int index = listBoxData.SelectedIndex;
            //Getting x and y pos using methods
            int x = CalcXPos(cols[index]);
            int y = CalcYPos(rowLetts[index]);
            //Using method to draw galaxy in red
            DisplayGalaxy(paper, x, y, Color.Red);
        }
    }
}

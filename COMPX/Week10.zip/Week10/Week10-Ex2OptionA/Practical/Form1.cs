﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Practical
{
    public partial class Form1 : Form
    {
        //Filter for csv files and all files
        const string FILTER = "CSV files|*.csv|Text Files|*.txt|All Files|*.*";
        //Maximum number of student data
        const int MAX_STUDENTS = 100;
        //An array to store all id numbers
        string[] idArray = new string[MAX_STUDENTS];
        //An array to store all the exam marks
        int[] markArray = new int[MAX_STUDENTS];
        //The number of students read from the file
        int numStudents = 0;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Will load a csv file of marks and store the data in appropriate arrays.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loadMarkFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StreamReader reader;
            string line = "";
            string[] csvArray;
            string id = "";
            int mark = 0;

            //Set filter for dialog control
            openFileDialog1.Filter = FILTER;
            //Check if the user has selected a file
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //Open the selected file
                reader = File.OpenText(openFileDialog1.FileName);
                //Repeat while it is not the end of the file
                while (!reader.EndOfStream)
                {
                    try
                    {
                        //Read a line from the file
                        line = reader.ReadLine();
                        //Split the line using an array
                        csvArray = line.Split(',');
                        //Check if the array has the correct number of elements
                        if (csvArray.Length == 2)
                        {
                            //Extract the values into separate variables
                            id = csvArray[0];
                            mark = int.Parse(csvArray[1]);
                            //Display the data in the listbox
                            listBoxData.Items.Add(id.PadRight(10) + mark);
                            //Store the values into the array using numStudents
                            //for the index position
                            idArray[numStudents] = id;
                            markArray[numStudents] = mark;
                            //Increase the number of students
                            numStudents++;
                        }
                        else
                        {
                            Console.WriteLine("Error: " + line);
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Error: " + line);
                    }
                }
                //Close the file

                reader.Close();
            }
        }
        /// <summary>
        /// Clear menu button
        /// Clears picturebox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void clearGraphToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBoxDisplay.Refresh();
        }
        /// <summary>
        /// Exit button
        /// Exits application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// CalculateBarHeight method
        /// Calculates height of bar in graph
        /// Example: CalculateBarHeight(mark)
        /// </summary>
        /// <param name="mark"></param>
        /// <returns></returns>
        private int CalculateBarHeight(int mark)
        {
            return pictureBoxDisplay.Height * mark / 100;
        }
        /// <summary>
        /// Graph Marks button
        /// graphs marks from students into picturebox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void graphMarksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Creating graphics objects
            Graphics graph = pictureBoxDisplay.CreateGraphics();
            Brush brush = new SolidBrush(Color.Gray);
            Pen pen = new Pen(Color.Black,2);
            //Graphing variables
            float width = pictureBoxDisplay.Width / MAX_STUDENTS;
            float x = 0;
            float y = 0;
            for(int i = 0; i < markArray.Length; i++)
            {
                //Getting height using current mark
                float height = CalculateBarHeight(markArray[i]);
                //Setting y coordinate so bars rise
                y = pictureBoxDisplay.Height - height;
                //Drawing bar and filling
                graph.DrawRectangle(pen, x, y, width, height);
                graph.FillRectangle(brush, x, y, width, height);
                //Changing x to move bar right
                x += width;
            }
        }
        /// <summary>
        /// CalcLetterGrade method
        /// Calculates letter grade using mark
        /// Example: CalcLetterGrade(mark)
        /// </summary>
        /// <param name="mark"></param>
        /// <returns></returns>
        private string CalcLetterGrade(int mark)
        {
            if(mark > 80)
            {
                return "A";
            }
            else if(mark > 65)
            {
                return "B";
            }
            else if(mark > 50)
            {
                return "C";
            }
            else if(mark > 35)
            {
                return "D";
            }
            else
            {
                return "E";
            }
        }
        /// <summary>
        /// Generate Report button
        /// creates text file using file dialog and writes ID, marks and letter grade to file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void generateReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StreamWriter writer;

            //Set filter for dialog control
            openFileDialog1.Filter = "Text Files|*.txt|All Files|*.*";
            //Check if the user has selected a file
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //Creating file or opening and deleting contents of file using file dialog
                writer = File.CreateText(openFileDialog1.FileName);

                //For loop to write lines to file
                for (int i = 0; i < markArray.Length; i++)
                {
                    //Writing line to file using padding
                    writer.WriteLine(string.Format("{0}{1}{2}", idArray[i], markArray[i].ToString().PadLeft(10), CalcLetterGrade(markArray[i]).PadLeft(10)));
                }
                writer.Close();
            }
        }
    }
}

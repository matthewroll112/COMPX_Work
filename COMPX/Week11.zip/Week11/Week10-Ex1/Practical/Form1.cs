﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Practical
{
    public partial class Form1 : Form
    {

        //The width of a bar in the bar graph
        const int BAR_WIDTH = 25;

        //the gap between bars in the bar graph
        const int GAP = 5;

        //the factor to scale the the graph by to make it fit nicely in the the picturebox
        const int SCALE_FACTOR = 15;

        //Filter for files
        const string FILTER = "Text Files|*.txt|CSV Files|*.csv|All Files|*.*";

        //Lists for data
        List<string> date = new List<string>();
        List<int> tcal = new List<int>();
        List<int> stepsL = new List<int>();
        List<double> dist = new List<double>();
        List<int> seden = new List<int>();
        List<int> light = new List<int>();
        List<int> fair = new List<int>();
        List<int> very = new List<int>();
        List<int> acal = new List<int>();
        //List<int> stepPerMtre = new List<int>();
        public Form1()
        {
            InitializeComponent();

            //Adding header to listbox output
            listBoxOutput.Items.Add(string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}{9}", "Date", "TCal".PadLeft(21), "Steps".PadLeft(15), "Dist".PadLeft(15), 
                "Seden".PadLeft(15), "Light".PadLeft(15), "Fair".PadLeft(15), "Very".PadLeft(15), "ACal".PadLeft(15), "steps/m".PadLeft(15)));
        }

        /// <summary>
        /// Draws a vertical bar that is part of a bar graph.
        /// i.e. It fills a rectangle at position (x,y) with the specified colour.
        /// Then draws a black outline for the rectangle.
        /// Uses the BAR_WIDTH constant for the size of the rectangle.
        /// </summary>
        /// <param name="paper">The Graphics object to draw on.</param>
        /// <param name="x">The x position of the top left corner of the rectangle.</param>
        /// <param name="y">The y position of the top left corner of the rectangle.</param>
        /// <param name="colour">The colour to fill the background of the rectangle with.</param>
        private void DrawABar(Graphics paper, int x, int y, int length, Color colour)
        {
            //create a brush of specified colour and fill background with this colour 
            SolidBrush brush = new SolidBrush(colour);
            paper.FillRectangle(brush, x, y, BAR_WIDTH, length);

            //draw outline in black
            paper.DrawRectangle(Pens.Black, x, y, BAR_WIDTH, length);
        }
        /// <summary>
        /// Exit button
        /// Exits application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// Clear button
        /// Clear 1st picturebox and listBoxOutput
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Clearing picture box
            pictureBoxTop.Refresh();
            //Clearing output list box
            listBoxOutput.Items.Clear();
        }

        /// <summary>
        /// Open file menu button
        /// Opens a file and reads line
        /// Displays line, uses padding for columns
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Making streamreader object & string var & int var
            StreamReader reader;
            string objectType;
            int steps = 0;
            //Co ordinate vars
            int y = 0; //Old y value
            int x = 0;
            //Graphics for picturebox a, and pens/brushes
            Graphics graphA = pictureBoxTop.CreateGraphics();
            //setting filter for file dialog control
            openFileDialog1.Filter = FILTER;
            //Checking if user has selected file to open
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //Open selected file
                reader = File.OpenText(openFileDialog1.FileName);

                //Process file using while loop
                while (!reader.EndOfStream)
                {
                    try
                    {
                        //Read line from file
                        objectType = reader.ReadLine();
                        //Split at comma
                        var values = objectType.Split(',');
                        //adding to total steps
                        steps += int.Parse(values[2]);

                        //Checking if correct number of elements has been read
                        if (values.Length == 9)
                        {
                            //Placing elements from values array into seperate variables
                            string num1 = values[0];
                            string num2 = values[1];
                            int num3 = int.Parse(values[2]);
                            double num4 = double.Parse(values[3]);
                            string num5 = values[4];
                            string num6 = values[5];
                            string num7 = values[6];
                            string num8 = values[7];
                            string num9 = values[8];
                            //Adding items to listbox
                            listBoxOutput.Items.Add(string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}{9}", num1, num2.PadLeft(15), num3.ToString().PadLeft(15), num4.ToString().PadLeft(15), num5.PadLeft(15), 
                                num6.PadLeft(15), num7.PadLeft(15), num8.PadLeft(15), num9.PadLeft(15), 
                                Math.Round(CalculateStepsPerMetre(num3, num4), 3).ToString().PadLeft(15)));
                            //New y value so bar "rises" instead of "falling"
                            y = pictureBoxTop.Height - Convert.ToInt32(num4) * SCALE_FACTOR;
                            //Adding bar to picturebox a
                            DrawABar(graphA, x, y, Convert.ToInt32(num4)*SCALE_FACTOR, Color.Green);
                            //Changing x value
                            x += BAR_WIDTH + GAP; //I added gap to make it look nicer
                            //Adding data into class scope lists
                            date.Add(num1);
                            tcal.Add(int.Parse(num2));
                            stepsL.Add(num3);
                            dist.Add(num4);
                            seden.Add(int.Parse(num5));
                            light.Add(int.Parse(num6));
                            fair.Add(int.Parse(num7));
                            very.Add(int.Parse(num8));
                            acal.Add(int.Parse(num9));
                        }
                        else
                        {
                            Console.WriteLine(string.Format("Error: {0}", reader.ReadLine()));
                        }
                    }
                    catch
                    {
                        Console.WriteLine(string.Format("Error: {0}", reader.ReadLine()));
                    }
                    
                }
                //Displaying total steps taken in msgbox
                MessageBox.Show("Total Steps Taken: " + steps, "Steps Total", MessageBoxButtons.OK);
                //Close file
                reader.Close();
            }
        }
        /// <summary>
        /// Calculates steps per metre
        /// Example: CalculateStepsPerMetre(steps, distance);
        /// </summary>
        /// <param name="steps"></param>
        /// <param name="distance"></param>
        /// <returns></returns>
        private double CalculateStepsPerMetre(int steps, double distance)
        {
            return steps / (distance * 1000);
        }
        /// <summary>
        /// Graphs data in form of days (monday, truesday etc.)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void graphDaysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Variables
            int y;
            int x = 0;
            //Graphics for bottom picture box
            Graphics graphB = pictureBoxBottom.CreateGraphics();
            //Colour array for bars
            Color[] colours = {Color.Red, Color.Orange, Color.Yellow, Color.Green, Color.Blue, Color.Indigo, Color.Violet};
            //Count for while loop and starting day
            int count = 0;
            //For loop for days
            while(count < 7)
            {
                for(int i = count; i < dist.Count; i += 7)
                {
                    //New y value so bar "rises" instead of "falling"
                    y = pictureBoxBottom.Height - Convert.ToInt32(dist[i]) * SCALE_FACTOR;
                    //Using DrawABar method to make bars in graph
                    DrawABar(graphB, x, y, Convert.ToInt32(dist[i])*SCALE_FACTOR, colours[count]);
                    //Changing x value for new bar
                    x += BAR_WIDTH + GAP;
                }
                count++;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WebBrowser
{
    public partial class Form1 : Form
    {
        //Class scope list for bookmarks
        List<string> bookmarks = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Forward button code, ->
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonForward_Click(object sender, EventArgs e)
        {
            webBrowser1.GoForward();
        }
        /// <summary>
        /// Back button code, <-
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonBack_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void buttonGo_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(textBoxUrl.Text);
        }
        /// <summary>
        /// Navigating event of webBrowser control
        /// Displays Loading...
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void webBrowser1_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            textBoxStatus.Text = "Loading...";
        }
        /// <summary>
        /// DocumentCompleted event of webBrowser control
        /// Navigates to website in url texbox and displays url in status textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            //Status textbox changing
            textBoxStatus.Text = webBrowser1.Document.Url.ToString();
            //Changing form title
            this.Text = webBrowser1.Document.Title;
        }
        /// <summary>
        /// Exit button code
        /// Closes application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// Adds bookmarks from list to listbox
        /// </summary>
        private void UpdateListbox()
        {
            //Clearing listbox
            listBox1.Items.Clear();
            //Adding each item in bookmarks list to listbox
            foreach (string bookmark in bookmarks)
            {
                listBox1.Items.Add(bookmark);
            }
        }
        /// <summary>
        /// Clears bookmarks list, listbox, url textbox
        /// </summary>
        private void Initialise()
        {
            //Clearing bookmarks list
            bookmarks.Clear();
            //Clearing listbox
            listBox1.Refresh();
            //Clearing url textbox
            textBoxUrl.Clear();
        }
        /// <summary>
        /// New Bookmark File menu event
        /// Uses initialise method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newBookmarkFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Initialise();
        }
        /// <summary>
        /// Adds bookmarks from url textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addBookmarkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Checking if url textbox is empty
            if(textBoxUrl.Text.Length == 0)
            {
                //Showing msgbox if url textbox is empty
                MessageBox.Show("No URL to add to bookmarks");
            }
            else
            {
                //Adding url to bookmarks list
                bookmarks.Add(textBoxUrl.Text);
                //Updating listbox
                UpdateListbox();
            }
        }
        /// <summary>
        /// Gets selected item from listbox then navigates to url
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Getting currently slected string
            string curItem = listBox1.SelectedItem.ToString();
            //Adding url to url textbox
            textBoxUrl.Text = curItem;
            //Navigating to url
            webBrowser1.Navigate(textBoxUrl.Text);
        }
        /// <summary>
        /// Loads file of bookmarks
        /// Adds file contents to list
        /// Updates listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loadBookmarkFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                //Declaring vars
                StreamReader reader;
                string line;
                //File dialog filter
                openFileDialog1.Filter = "Text Files|*.txt|All Files|*.*";
                if(openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    //Initialise method
                    Initialise();
                    reader = File.OpenText(openFileDialog1.FileName);
                    while (!reader.EndOfStream)
                    {
                        line = reader.ReadLine();

                        //Adding line to bookmarks list
                        bookmarks.Add(line);
                    }
                    reader.Close();
                    listBox1.Items.AddRange(bookmarks.ToArray());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /// <summary>
        /// Creates file
        /// Saves bookmarks list to file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveBookmarkFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Displaying SaveFileDialog
            StreamWriter writer;
            saveFileDialog1.Filter = "Text Files|*.txt|All Files|*.*";
            if(saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //Creating file
                writer = File.CreateText(saveFileDialog1.FileName);
                //Writing bookmarks list to file
                foreach(string item in bookmarks)
                {
                    writer.WriteLine(item);
                }
                //Closing file
                writer.Close();
            }
        }
        /// <summary>
        /// Deletes listbox item selected from list and listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            //Deleting listbox item from bookmarks list
            int index = listBox1.SelectedIndex;
            bookmarks.RemoveAt(index);
            //Updating listbox
            UpdateListbox();
        }
    }
}
